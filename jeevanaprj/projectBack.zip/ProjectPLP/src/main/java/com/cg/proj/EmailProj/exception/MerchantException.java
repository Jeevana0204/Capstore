package com.cg.proj.EmailProj.exception;

public class MerchantException extends Exception {

	public MerchantException() {
		super();
	
	}

	public MerchantException(String message) {
		super(message);
		
	}

	

}
