package com.cg.proj.EmailProj.controller;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.proj.EmailProj.bean.CustomerBean;
import com.cg.proj.EmailProj.bean.MerchantBean;
import com.cg.proj.EmailProj.exception.MerchantException;
import com.cg.proj.EmailProj.service.IEmailService;
@RestController
public class MailController {
	@Autowired
	private IEmailService EmailServiceImpl;
	@Autowired
	private JavaMailSender javaMailSender;
	/*@Autowired
	public MailController(JavaMailSender javaMailSender)
	{
		this.javaMailSender=javaMailSender;
		
	}*/
	
	@RequestMapping(value="/")
	public String check()
	{
		return "hello BACK RUNNING";
	}
	
/*	@RequestMapping(value="/sendMail", method=RequestMethod.POST)
	public String sendRegisteredMail(@RequestBody String name) throws MessagingException {
		System.err.println("In Back Controller--- Name:"+name);
		String customerEmail = EmailServiceImpl.RegiteredNewUser(name);
		//sendInvitationToFriend(friendEmail);
		//sendRegisteredNewUser(name);
		System.err.println("Out Back Controller--- Name:"+customerEmail);
		return "details have been sent to your register mailid "+customerEmail;
	}*/
	
	
	/*@RequestMapping(value="/sendInvitation", method=RequestMethod.GET)
	public String inviteFriend(String name, String Email) throws MessagingException {
	String Email = EmailServiceImpl.sendInvitation(name);
	//sendInvitationToFriend(friendEmail);
	return "Success, Sending invitation to "+ friendEmail+ "from your mail "+customerEmail ;
	}

	private void sendInvitationToFriend(String friendmail) throws MessagingException {
	MimeMessage message = sender.createMimeMessage();
	MimeMessageHelper helper = new MimeMessageHelper(message);

	//helper.setFrom(customerEmail);
	helper.setTo(friendmail);
	helper.setText("Test Message...");
	helper.setSubject("Inviting You to Buy Products from this website");

	sender.send(message);
	}
	*/
	/*@RequestMapping(value="/sendInvi", method=RequestMethod.GET)
	public String sentInvitationToCustomer(String email) throws MessagingException
	{
		String customer =EmailServiceImpl.sentInvitationToCustomer(email);
		System.out.println(customer);
		return "details sent"+customer;
	}*/
	
	
	private void sendRegisteredNewUser(String name) throws MessagingException
	{
		MimeMessage message=javaMailSender.createMimeMessage();
		MimeMessageHelper helper=new MimeMessageHelper(message);
		helper.setTo(EmailServiceImpl.RegiteredNewUser(name));
		helper.setText("you are invited to sell this product");
		helper.setSubject("Invitation ");
		javaMailSender.send(message);
	}
	

	@RequestMapping(value="/sendInvitationToMerchant", method=RequestMethod.POST)
	public String inviteMerchant(@RequestBody String Email) throws MessagingException {
		System.err.println("IN BACK CONTROLLER...");
		System.err.println("email of customer:"+Email);
		MerchantBean merchantBean;
		try {
			merchantBean = EmailServiceImpl.sendInvitationToMerchant(Email);
		} catch (MerchantException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//String name=merchantBean.getMerchantName();
		//System.err.println("Back--- Name:"+name);
		return "Invitation has been sent successfully to "+Email;
	
	}

}                                        
